import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Program {
    // Точка входа в программу
    public static void main(String[] args) {
        // Ввод данных из консоли и начало работы программы
        getInput();
    }

    public static void getInput() {
        Scanner in = new Scanner(System.in);
        String input = in.nextLine();
        String[] inputComponents = input.split(" ");
        if (inputComponents.length != 3) {
            System.out.println("Wrong input!");
            System.exit(-1);
        }
        String code = inputComponents[1].replace("--code=", "");
        String date = inputComponents[2].replace("--date=", "").replace("-", "");
        parseXML(code, date);
    }

    public static void parseXML(String code, String date) {
        try {
            URL url = new URL(createUrlString(date));
            URLConnection connection = url.openConnection();
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document document = builder.parse(connection.getInputStream());
            findCurrentValue(document, code);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Could not connect to the site by url");
            System.exit(-1);
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
            System.out.println("Could not build XML-document");
            System.exit(-1);
        } catch (SAXException e) {
            e.printStackTrace();
            System.out.println("Could not parse data from the page");
            System.exit(-1);
        }
    }

    public static void findCurrentValue(Document document, String code) {
        NodeList valutes = document.getElementsByTagName("Valute");
        for (int i = 0; i < valutes.getLength(); i++) {
            Node valute = valutes.item(i);
            Element el = (Element) valute;
            if (el.getElementsByTagName("CharCode").item(0).getTextContent().equals(code)) {
                String resultName = el.getElementsByTagName("Name").item(0).getTextContent();
                String resultValue = el.getElementsByTagName("Value").item(0).getTextContent();
                System.out.println(code + " (" + resultName + "): " + resultValue);
                break;
            }
        }
    }

    public static String createUrlString(String date) {
        String transformedDate = date.substring(6, 8) + "/" + date.substring(4, 6) + "/" + date.substring(0, 4);
        return "http://www.cbr.ru/scripts/XML_daily.asp?date_req=" + transformedDate;
    }
}
